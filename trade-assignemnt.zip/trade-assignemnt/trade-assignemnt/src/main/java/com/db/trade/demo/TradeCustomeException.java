/**
 * 
 */
package com.db.trade.demo;

/**
 *@author Satish Tiwari
 *
 */
public class TradeCustomeException extends RuntimeException{

	/**
	 * Version ID.
	 */
	private static final long serialVersionUID = 11219321L;
	
	/**
	 * errorMessage.
	 */
	private String erroeMessage;
	/**
	 * errorCode
	 */
	private String errorCode;
	
	public TradeCustomeException(String erroeMessage, String errorCode) {
		super();
		this.erroeMessage = erroeMessage;
		this.errorCode = errorCode;
	}

	public String getErroeMessage() {
		return erroeMessage;
	}

	public void setErroeMessage(String erroeMessage) {
		this.erroeMessage = erroeMessage;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	
	

}
