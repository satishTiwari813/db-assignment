/**
 * 
 */
package com.db.trade.demo;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

/**
 * @author Satish Tiwari 
 *
 */
@Configuration
@EnableScheduling
@ComponentScan("com.db.trade.demo")
public class TradingSchedular {
	
	/**
	 * Using this map as Database 
	 */
	public Map<String, TradeDto> tradeDataBase = new HashMap<String, TradeDto>();
	
	// This corn Job will run each 24 hour
	@Scheduled(cron="0 0 1 * * *")
	public void updateExpireFlag() {
		Date date = new Date();
		
		Map<String, TradeDto> tradeMap = tradeDataBase.entrySet().stream()
				.filter(x -> x.getValue().getCreatedDate().equals(date))
				.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
		
		
		tradeMap.forEach((k,v)->{
			updateExpireFlagIfTradeCrossMaturityDate(v);
			tradeDataBase.put(k, v);
			
		});
		
		
		
	}

	/**
	 * @param existingTrade , not null
	 * @param tradeDto2 , not null
	 */
	private void updateExpireFlagIfTradeCrossMaturityDate(TradeDto dto) {
		if (dto.getCreatedDate().before(dto.getMaturityDate())) {
			dto.setExipred('Y');
		}

	}


	
	public Map<String, TradeDto> getTradeDataBase() {
		return tradeDataBase;
	}

	public void setTradeDataBase(Map<String, TradeDto> tradeDataBase) {
		this.tradeDataBase = tradeDataBase;
	}

}
