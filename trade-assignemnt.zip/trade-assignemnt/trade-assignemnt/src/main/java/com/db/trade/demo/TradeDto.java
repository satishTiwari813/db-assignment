/**
 * 
 */
package com.db.trade.demo;

import java.util.Date;

/**
 * @author Satish Tiwari
 *
 */
public class TradeDto {
	
	private String tradeId;
	
	private int  version;
	
	private String counterPartyId;
	
	private String bookId;
	
	//  date format is dd/MM/yyyy
	private Date maturityDate;
	
	//date format is dd/MM/yyyy
	private Date createdDate;
	
	private char exipred;
	
	

	public String getTradeId() {
		return tradeId;
	}

	public void setTradeId(String tradeId) {
		this.tradeId = tradeId;
	}

	public int getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}

	public String getCounterPartyId() {
		return counterPartyId;
	}

	public void setCounterPartyId(String counterPartyId) {
		this.counterPartyId = counterPartyId;
	}

	public String getBookId() {
		return bookId;
	}

	public void setBookId(String bookId) {
		this.bookId = bookId;
	}

	public Date getMaturityDate() {
		return maturityDate;
	}

	public void setMaturityDate(Date maturityDate) {
		this.maturityDate = maturityDate;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public char getExipred() {
		return exipred;
	}

	public void setExipred(char exipred) {
		this.exipred = exipred;
	}

	public TradeDto(String tradeId, int version, String counterPartyId, String bookId, Date maturityDate,
			Date createdDate, char exipred) {
		super();
		this.tradeId = tradeId;
		this.version = version;
		this.counterPartyId = counterPartyId;
		this.bookId = bookId;
		this.maturityDate = maturityDate;
		this.createdDate = createdDate;
		this.exipred = exipred;
	}

	

	
	
	
	
	
	

}
