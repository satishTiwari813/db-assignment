/**
 * 
 */
package com.db.trade.demo;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author Satish Tiwari
 *
 */
public class TradingStoreService {
	
	/**
	 * Using this map as Database 
	 */
	public Map<String, TradeDto> tradeDataBase = new HashMap<String, TradeDto>();
	
	public void storeTrade(TradeDto requestDto) {
		// fetch if trade existing already in TradeDatabase

		Map<String, TradeDto> tradeMap = tradeDataBase.entrySet().stream()
				.filter(x -> x.getKey().equalsIgnoreCase(requestDto.getTradeId()))
				.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
		if (!tradeMap.isEmpty()) {
			TradeDto tradeExsiting = tradeMap.get(requestDto.getTradeId());
			validateTradeVersion(tradeExsiting, requestDto.getVersion());
			validateTradeMaturityDate(requestDto.getMaturityDate());
			//updateExpireFlagIfTradeCrossMaturityDate(tradeExsiting, requestDto);
			tradeDataBase.put(requestDto.getTradeId(), requestDto);

		} else {
			tradeDataBase.put(requestDto.getTradeId(), requestDto);
		}

	}


	
	/**
	 * @param existingTrade , not null
	 * @param tradeDto2 , not null
	 */
	private void updateExpireFlagIfTradeCrossMaturityDate(TradeDto existingTrade, TradeDto tradeDto2) {
		if (existingTrade.getCreatedDate().before(existingTrade.getMaturityDate())) {
			tradeDto2.setExipred('Y');
		}

	}





	/**
	 * Validate TradeMaturityDate
	 * @param maturityDate , not null
	 */
	private void validateTradeMaturityDate(Date maturityDate) {
		if (maturityDate.before(new Date())) {
			throw new TradeCustomeException("Unable to allow the trade which has less maturity date then today date",
					"1002");
		}

	}





	




	private void validateTradeVersion(TradeDto trade, int version) {
		if (trade.getVersion() > version) {
			throw new TradeCustomeException(DBConstatnt.TRADE_VERSION_ERROR, "1001");
		}

		
	}


	
	public Map<String, TradeDto> getTradeDataBase() {
		return tradeDataBase;
	}



	public void setTradeDataBase(Map<String, TradeDto> tradeDataBase) {
		this.tradeDataBase = tradeDataBase;
	}


}
