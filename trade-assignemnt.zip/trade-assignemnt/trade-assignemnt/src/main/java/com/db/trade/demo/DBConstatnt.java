package com.db.trade.demo;

public class DBConstatnt {
	
	public static String TRADE_VERSION_ERROR ="Unable to store a trade because of lower trade version";
	
	public static String TRADE_LESS_MAJORITYDATE_ERROR ="Unable to allow the trade which has less maturity date then today date";  

}
