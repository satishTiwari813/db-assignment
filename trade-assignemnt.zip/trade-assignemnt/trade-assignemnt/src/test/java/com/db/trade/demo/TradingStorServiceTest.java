/**
 * 
 */
package com.db.trade.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * @author Satish Tiwari 
 *
 */

public class TradingStorServiceTest {
	
	TradingStoreService tradingStoreService;
	
	@BeforeEach
	public void setUp() throws Exception {
		tradingStoreService = new TradingStoreService();
		Map<String, TradeDto> tradeDataBase = new HashMap<>();
		
		
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		 Date date = formatter.parse("15/11/2022");
		 
		
		tradeDataBase.put("T1", new TradeDto("T1", 1, "CP-1", "B1", date, new Date(), 'f'));
		tradeDataBase.put("T2", new TradeDto("T2", 2, "CP-2", "B1", date, new Date(), 'f'));
		tradeDataBase.put("T3", new TradeDto("T3", 3, "CP-3", "B2", date, new Date(), 'Y') );
		tradingStoreService.setTradeDataBase(tradeDataBase);
		
		
		
	}

	@Test
	public void testIfTradeHasLowerVersion_ThrowException(){
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		 Date date = null;
		try {
			date = formatter.parse("15/11/2022");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		TradeDto requestDto =  new TradeDto("T2", 1, "CP-2", "B1", date, new Date(), 'f');
		try {
			tradingStoreService.storeTrade(requestDto );
		}catch(TradeCustomeException ex) {
			assertEquals(DBConstatnt.TRADE_VERSION_ERROR, ex.getErroeMessage());
			
		}
		
		
	}
	
	
	@Test
	public void testIfTradeHasLessMaturityDateAsToday_ThrowException() {
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		Date date = null;
		try {
			date = formatter.parse("14/11/2022");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		TradeDto requestDto = new TradeDto("T5", 1, "CP-2", "B1", date, new Date(), 'f');
		try {
			tradingStoreService.storeTrade(requestDto);
		} catch (TradeCustomeException ex) {
			assertEquals(DBConstatnt.TRADE_LESS_MAJORITYDATE_ERROR,
					ex.getErroeMessage());

		}

	}
	
	
}
