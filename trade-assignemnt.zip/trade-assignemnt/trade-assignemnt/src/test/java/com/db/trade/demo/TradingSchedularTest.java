package com.db.trade.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;

@SpringJUnitConfig(TradingSchedular.class)
public class TradingSchedularTest {
	@Autowired
	TradingSchedular schedular;
	
	@BeforeEach
	public void setUp() throws Exception {
		schedular = new TradingSchedular();
		Map<String, TradeDto> tradeDataBase = new HashMap<>();
		
		
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		 Date date = formatter.parse("15/11/2022");
		 
		
		tradeDataBase.put("T1", new TradeDto("T1", 1, "CP-1", "B1", date, new Date(), 'f'));
		tradeDataBase.put("T2", new TradeDto("T2", 2, "CP-2", "B1", date, new Date(), 'f'));
		tradeDataBase.put("T3", new TradeDto("T3", 3, "CP-3", "B2", date, new Date(), 'N') );
		schedular.setTradeDataBase(tradeDataBase);
		
		
		
	}
	
	@Test
	public void testAutomaticUpdateExpiredFlag(){
		
		
		
		try {
			Thread.sleep(100L);
			schedular.updateExpireFlag();
		} catch (InterruptedException e) {
			
		}
		TradeDto tradeDto = schedular.getTradeDataBase().get("T3");
		assertEquals(tradeDto.getExipred(),'Y');
		
		
		
	}

}
